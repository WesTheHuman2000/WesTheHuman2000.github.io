$(document).ready(function() {


        // preload the image for each link
        $("#image_list a").each(function() { 
                var buildImage = new Image(); 
                buildImage.src = $(this).attr("href"); 
            });

        $("#image_list a").click(function(evt){
                var imageHref = $(this).attr("href"); 
                var imageCaption = $(this).attr("description");
                var detDescription =$(this).attr("detailedDescription");
                $("#description").fadeOut(3000);
                $("#detailedDescription").fadeOut(3000);
                $("#main_image").fadeOut(3000, function(){
                        $("#main_image").attr("src", imageHref);
                        $("#description").text(imageCaption);
                        $("#detailedDescription").text(detDescription);
                });
                
                $("#main_image").fadeIn(3000);
                $("#description").fadeIn(3000);
                $("#detailedDescription").fadeIn(3000);
                evt.preventDefault();
        });
});